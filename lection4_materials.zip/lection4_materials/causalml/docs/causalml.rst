causalml package
================

Submodules
----------

causalml.inference.tree module
------------------------------

.. automodule:: causalml.inference.tree
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:

causalml.inference.meta module
------------------------------

.. automodule:: causalml.inference.meta
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:

causalml.optimize module
------------------------

.. automodule:: causalml.optimize
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:

causalml.dataset module
-----------------------

.. automodule:: causalml.dataset
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:

causalml.match module
---------------------

.. automodule:: causalml.match
    :members:
    :undoc-members:
    :show-inheritance:

causalml.propensity module
--------------------------

.. automodule:: causalml.propensity
    :members:
    :undoc-members:
    :show-inheritance:


causalml.metrics module
-----------------------

.. automodule:: causalml.metrics
    :members:
    :imported-members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: causalml
    :members:
    :undoc-members:
    :show-inheritance:
